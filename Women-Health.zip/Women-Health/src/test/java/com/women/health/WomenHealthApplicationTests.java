package com.women.health;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WomenHealthApplicationTests {

	@Test
	void contextLoads() {
	}

}
