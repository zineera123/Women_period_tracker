package com.women.health;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.ArrayList;
import java.util.LinkedList;

@SpringBootApplication
public class WomenHealthApplication {

	public static void main(String[] args) {
		SpringApplication.run(WomenHealthApplication.class, args);
	}

}
